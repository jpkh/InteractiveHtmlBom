#!/usr/bin/python3
from __future__ import absolute_import

import argparse
import os
import sys

# Add ../ to the path
# Works if this script is executed without installing the module
script_dir = os.path.dirname(os.path.abspath(os.path.realpath(__file__)))
sys.path.insert(0, os.path.dirname(script_dir))
# Pretend we are part of a module
# Avoids: ImportError: attempted relative import with no known parent package
__package__ = os.path.basename(script_dir)
__import__(__package__)


# python 2 and 3 compatibility hack
def to_utf(s):
    if isinstance(s, bytes):
        return s.decode('utf-8')
    else:
        return s


def main():
    from .compat import get_wx, should_create_wx_app
    wx = get_wx()
    create_wx_app = should_create_wx_app()

    if wx is None and create_wx_app:
        print("wxpython is required unless INTERACTIVE_HTML_BOM_NO_DISPLAY "
              "environment variable is set")
        sys.exit(1)

    if wx is not None:
        if create_wx_app:
            app = wx.App()
            if hasattr(wx, "APP_ASSERT_SUPPRESS"):
                app.SetAssertMode(wx.APP_ASSERT_SUPPRESS)
        elif hasattr(wx, "DisableAsserts"):
            wx.DisableAsserts()

    from .core import ibom
    from .core.config import Config
    from .ecad import get_parser_by_extension
    from .version import version
    from .errors import (ExitCodes, ParsingException, exit_error)


    parser = argparse.ArgumentParser(
            description='KiCad InteractiveHtmlBom plugin CLI.',
            formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument('file',
                        type=lambda s: to_utf(s),
                        help="KiCad PCB file")

    Config.add_options(parser, version)
    logger = ibom.Logger(cli=True)

    # First pass over the arguments to find the pcb file and --use-ini.
    pre_args, _ = parser.parse_known_args()

    if not os.path.isfile(pre_args.file):
        exit_error(logger, ExitCodes.ERROR_FILE_NOT_FOUND,
                   "File %s does not exist." % pre_args.file)

    config = Config(version,
                    os.path.dirname(os.path.abspath(pre_args.file)))

    # With --use-ini the ini values are installed as parser defaults before
    # the final parse: options given on the command line override the ini
    # while all other options fall back to the ini values.
    if pre_args.use_ini and not pre_args.show_dialog:
        ini_defaults = config.get_ini_defaults()
        if ini_defaults is None:
            exit_error(logger, ExitCodes.ERROR_FILE_NOT_FOUND,
                       "No ibom ini file found in usual locations.")
        else:
            parser.set_defaults(**ini_defaults)

    args = parser.parse_args()

    print("Loading %s" % args.file)

    config.kicad_variant = args.kicad_variant

    parser = get_parser_by_extension(
        os.path.abspath(args.file), config, logger)

    if args.show_dialog:
        if not create_wx_app:
            exit_error(logger, ExitCodes.ERROR_NO_DISPLAY,
                       "Can not show dialog when "
                       "INTERACTIVE_HTML_BOM_NO_DISPLAY is set.")
        try:
            ibom.run_with_dialog(parser, config, logger)
        except ParsingException as e:
            exit_error(logger, ExitCodes.ERROR_PARSE, e)
    else:
        config.set_from_args(args)
        try:
            ibom.main(parser, config, logger)
        except ParsingException as e:
            exit_error(logger, ExitCodes.ERROR_PARSE, str(e))
    return 0


if __name__ == "__main__":
    main()
